package com.example.appbiometrica;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.fragment.app.FragmentActivity;

public class MainActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton faceButton = findViewById(R.id.faceButton);
        faceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBiometricDialog();
            }
        });
    }

    private void showBiometricDialog() {
        BiometricDialog biometricDialog = new BiometricDialog(MainActivity.this);
        biometricDialog.showBiometricPopup();
    }
}
