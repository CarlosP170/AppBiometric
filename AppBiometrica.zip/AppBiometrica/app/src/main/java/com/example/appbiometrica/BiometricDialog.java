package com.example.appbiometrica;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import java.util.concurrent.Executor;

public class BiometricDialog {

    private FragmentActivity activity;
    private PopupWindow biometricPopup;
    private View popupView;
    private ImageView faceImage;
    private ImageView verifyImage;
    private TextView descriptionTextView;

    public BiometricDialog(FragmentActivity activity) {
        this.activity = activity;
    }

    public void showBiometricPopup() {
        try {
            LayoutInflater inflater = LayoutInflater.from(activity);
            popupView = inflater.inflate(R.layout.biometric_dialog, null);

            biometricPopup = new PopupWindow(popupView,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            biometricPopup.setFocusable(true);

            biometricPopup.showAtLocation(popupView, Gravity.BOTTOM, 0, 0);

            faceImage = popupView.findViewById(R.id.faceImage);
            verifyImage = popupView.findViewById(R.id.verifyImage);
            descriptionTextView = popupView.findViewById(R.id.descriptionTextView);

            configurePopupButtons();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void configurePopupButtons() {
        if (popupView != null) {
            faceImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    performFaceRecognition();
                }
            });

            Button cancelButton = popupView.findViewById(R.id.cancelButton);
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dismissBiometricPopup();
                }
            });
        }
    }

    private void performFaceRecognition() {
        Executor executor = ContextCompat.getMainExecutor(activity);
        BiometricPrompt biometricPrompt = new BiometricPrompt(activity, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                descriptionTextView.setText("Error de autenticación");
            }

            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                faceImage.setVisibility(View.GONE);
                verifyImage.setVisibility(View.VISIBLE);
                descriptionTextView.setText("¡Reconocimiento facial exitoso! Iniciando sesión...");

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        redirectToInicioActivity();
                    }
                }, 1500);
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                faceImage.setImageResource(R.drawable.error);
                descriptionTextView.setText("No hay coincidencias biométricas");
            }
        });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Verificación biométrica")
                .setNegativeButtonText("Cancelar")
                .build();

        biometricPrompt.authenticate(promptInfo);
    }

    private void dismissBiometricPopup() {
        if (biometricPopup != null && biometricPopup.isShowing()) {
            biometricPopup.dismiss();
        }
    }

    private void redirectToInicioActivity() {
        dismissBiometricPopup();
        Intent intent = new Intent(activity, InicioActivity.class);
        activity.startActivity(intent);
    }
}
